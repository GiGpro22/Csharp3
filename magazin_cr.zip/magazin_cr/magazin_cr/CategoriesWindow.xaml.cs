using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace magazin_cr
{
    public partial class CategoriesWindow : Window
    {
        private magazinDataSet magazDS;
        private magazinDataSetTableAdapters.CategoriesTableAdapter categoriesTA;

        public CategoriesWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                magazDS = new magazinDataSet();
                categoriesTA = new magazinDataSetTableAdapters.CategoriesTableAdapter();

                categoriesTA.Fill(magazDS.Categories);
                CategoriesGrid.ItemsSource = magazDS.Categories.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddCategory_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new EditCategoryWindow();
            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    // Создаем новую строку в таблице Categories
                    magazinDataSet.CategoriesRow newCategoryRow = magazDS.Categories.NewCategoriesRow();
                    newCategoryRow.name = editWindow.CategoryName;
                    newCategoryRow.description = editWindow.CategoryDescription;

                    // Добавляем строку в коллекцию строк
                    magazDS.Categories.AddCategoriesRow(newCategoryRow);

                    // Обновляем базу данных с помощью TableAdapter
                    categoriesTA.Update(magazDS.Categories);

                    LoadData();
                    MessageBox.Show("Категория успешно добавлена!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении категории: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void EditCategory_Click(object sender, RoutedEventArgs e)
        {
            if (CategoriesGrid.SelectedItem == null) return;

            DataRowView row = (DataRowView)CategoriesGrid.SelectedItem;
            var editWindow = new EditCategoryWindow(
                "Редактирование категории",
                row["name"].ToString(),
                row["description"].ToString());

            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    row["name"] = editWindow.CategoryName;
                    row["description"] = editWindow.CategoryDescription;
                    categoriesTA.Update(magazDS.Categories);
                    LoadData();
                    MessageBox.Show("Категория успешно обновлена!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении категории: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteCategory_Click(object sender, RoutedEventArgs e)
        {
            if (CategoriesGrid.SelectedItem == null) return;

            var result = MessageBox.Show(
                "Вы уверены, что хотите удалить эту категорию?\n\n" +
                "Внимание: Если категория используется в моделях, удаление будет невозможно.",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes) return;

            try
            {
                DataRowView row = (DataRowView)CategoriesGrid.SelectedItem;
                row.Delete();
                categoriesTA.Update(magazDS.Categories);
                LoadData();
                MessageBox.Show("Категория успешно удалена!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Ошибка при удалении категории: {ex.Message}\n\n" +
                    "Возможно, эта категория используется в таблице моделей.",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                LoadData(); // Перезагружаем данные в случае ошибки
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void CategoriesGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool hasSelection = CategoriesGrid.SelectedItem != null;
            btnEdit.IsEnabled = hasSelection;
            btnDelete.IsEnabled = hasSelection;
        }
    }
} 