﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace magazin_cr
{
    /// <summary>
    /// Логика взаимодействия для EditProductWindow.xaml
    /// </summary>
    public partial class EditProductWindow : Window
    {
        private magazinDataSet magazDS;
        private magazinDataSetTableAdapters.ModelsTableAdapter modelsTA;
        private magazinDataSetTableAdapters.SizesTableAdapter sizesTA;

        public int SelectedModelId { get; private set; }
        public int SelectedSizeId { get; private set; }
        public string Sku { get; private set; }
        public string Color { get; private set; }

        // Конструктор для добавления продукта
        public EditProductWindow()
        {
            InitializeComponent();
            Title = "Добавление продукта";
            LoadComboBoxData();
        }

        // Конструктор для редактирования продукта
        public EditProductWindow(DataRowView productRowView)
        {
            InitializeComponent();
            Title = "Редактирование продукта";
            LoadComboBoxData();

            // Заполнение полей данными из выбранной строки
            DataRow productRow = productRowView.Row; // Explicitly get the DataRow
            ModelComboBox.SelectedValue = productRow["model_ID"];
            SizeComboBox.SelectedValue = productRow["size_ID"];
            SkuTextBox.Text = productRow["sku"].ToString();
            ColorTextBox.Text = productRow["color"].ToString();
        }

        private void LoadComboBoxData()
        {
            try
            {
                magazDS = new magazinDataSet();
                modelsTA = new magazinDataSetTableAdapters.ModelsTableAdapter();
                sizesTA = new magazinDataSetTableAdapters.SizesTableAdapter();

                modelsTA.Fill(magazDS.Models);
                sizesTA.Fill(magazDS.Sizes);

                ModelComboBox.ItemsSource = magazDS.Models.DefaultView;
                SizeComboBox.ItemsSource = magazDS.Sizes.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных для списков: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ModelComboBox.SelectedValue == null)
            {
                MessageBox.Show("Пожалуйста, выберите модель продукта.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (SizeComboBox.SelectedValue == null)
            {
                MessageBox.Show("Пожалуйста, выберите размер продукта.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // SKU и Color допускают NULL в вашей схеме, валидация на пустоту не требуется, 
            // но можно добавить проверку формата, если нужно

            SelectedModelId = (int)ModelComboBox.SelectedValue;
            SelectedSizeId = (int)SizeComboBox.SelectedValue;
            Sku = SkuTextBox.Text.Trim();
            Color = ColorTextBox.Text.Trim();

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
