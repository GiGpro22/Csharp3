﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace magazin_cr
{
    /// <summary>
    /// Логика взаимодействия для SizesWindow.xaml
    /// </summary>
    public partial class SizesWindow : Window
    {
        private magazinDataSet magazDS;
        private magazinDataSetTableAdapters.SizesTableAdapter sizesTA;

        public SizesWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                magazDS = new magazinDataSet();
                sizesTA = new magazinDataSetTableAdapters.SizesTableAdapter();

                sizesTA.Fill(magazDS.Sizes);
                SizesGrid.ItemsSource = magazDS.Sizes.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SizesGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isRowSelected = SizesGrid.SelectedItem != null;
            EditSize.IsEnabled = isRowSelected;
            DeleteSize.IsEnabled = isRowSelected;
        }

        private void AddSize_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new EditSizeWindow();
            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    // Создаем новую строку в таблице Sizes
                    magazinDataSet.SizesRow newSizeRow = magazDS.Sizes.NewSizesRow();
                    newSizeRow.size = editWindow.Size;
                    newSizeRow.eu_size = editWindow.EuSize;
                    newSizeRow.us_size = editWindow.UsSize;
                    newSizeRow.uk_size = editWindow.UkSize;

                    // Добавляем строку в коллекцию строк
                    magazDS.Sizes.AddSizesRow(newSizeRow);

                    // Обновляем базу данных с помощью TableAdapter
                    sizesTA.Update(magazDS.Sizes);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении размера: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void EditSize_Click(object sender, RoutedEventArgs e)
        {
            if (SizesGrid.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите размер для редактирования",
                    "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)SizesGrid.SelectedItem;
            var editWindow = new EditSizeWindow
            {
                Size = row["size"].ToString(),
                EuSize = row["eu_size"].ToString(),
                UsSize = row["us_size"].ToString(),
                UkSize = row["uk_size"].ToString()
            };

            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    row["size"] = editWindow.Size;
                    row["eu_size"] = editWindow.EuSize;
                    row["us_size"] = editWindow.UsSize;
                    row["uk_size"] = editWindow.UkSize;

                    sizesTA.Update(magazDS.Sizes);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении размера: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteSize_Click(object sender, RoutedEventArgs e)
        {
            if (SizesGrid.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите размер для удаления",
                    "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var result = MessageBox.Show("Вы уверены, что хотите удалить выбранный размер?",
                "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    DataRowView row = (DataRowView)SizesGrid.SelectedItem;
                    row.Delete();
                    sizesTA.Update(magazDS.Sizes);
                    LoadData();
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    // Код ошибки 547 обычно указывает на конфликт внешнего ключа
                    if (ex.Number == 547)
                    {
                        MessageBox.Show("Невозможно удалить размер, так как он используется в других записях (например, в продуктах).",
                            "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        MessageBox.Show($"Ошибка базы данных при удалении размера: {ex.Message}",
                            "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении размера: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
