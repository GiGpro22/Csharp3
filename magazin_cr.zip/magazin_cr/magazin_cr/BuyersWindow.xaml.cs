using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace magazin_cr
{
    /// <summary>
    /// Логика взаимодействия для BuyersWindow.xaml
    /// </summary>
    public partial class BuyersWindow : Window
    {
        private magazinDataSet magazinDS;
        private magazinDataSetTableAdapters.BuyersTableAdapter buyersTA;

        public BuyersWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                magazinDS = new magazinDataSet();
                buyersTA = new magazinDataSetTableAdapters.BuyersTableAdapter();

                buyersTA.Fill(magazinDS.Buyers);
                BuyersGrid.ItemsSource = magazinDS.Buyers.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных покупателей: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BuyersGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView selectedRow = BuyersGrid.SelectedItem as DataRowView;
            bool hasSelection = selectedRow != null;
            EditBuyer.IsEnabled = hasSelection;
            DeleteBuyer.IsEnabled = hasSelection;
        }

        private void AddBuyer_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new EditBuyerWindow();
            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    // Создаем новую строку в таблице Buyers
                    magazinDataSet.BuyersRow newBuyerRow = magazinDS.Buyers.NewBuyersRow();
                    newBuyerRow.first_name = editWindow.FirstName;
                    newBuyerRow.last_name = editWindow.LastName;
                    newBuyerRow.email = editWindow.Email; // Email и Phone могут быть NULL, нужно проверить
                    newBuyerRow.phone = editWindow.Phone;

                    // Добавляем строку в коллекцию строк
                    magazinDS.Buyers.AddBuyersRow(newBuyerRow);

                    // Обновляем базу данных
                    buyersTA.Update(magazinDS.Buyers);
                    LoadData();
                    MessageBox.Show("Покупатель успешно добавлен!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                 catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении покупателя: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void EditBuyer_Click(object sender, RoutedEventArgs e)
        {
             if (BuyersGrid.SelectedItem == null) return;

            DataRowView selectedRowView = (DataRowView)BuyersGrid.SelectedItem;
            var editWindow = new EditBuyerWindow(selectedRowView);

            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    // Получаем оригинальную DataRow для обновления
                    DataRow buyerRow = selectedRowView.Row;

                    // Обновляем DataRow данными из окна редактирования
                    buyerRow["first_name"] = editWindow.FirstName;
                    buyerRow["last_name"] = editWindow.LastName;
                    buyerRow["email"] = editWindow.Email; // Email и Phone могут быть NULL
                    buyerRow["phone"] = editWindow.Phone;

                    // Обновляем базу данных
                    buyersTA.Update(magazinDS.Buyers);
                    LoadData();
                    MessageBox.Show("Покупатель успешно обновлён!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                 catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении покупателя: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteBuyer_Click(object sender, RoutedEventArgs e)
        {
            // Логика удаления покупателя
            if (BuyersGrid.SelectedItem == null) return;

            DataRowView selectedRow = (DataRowView)BuyersGrid.SelectedItem;

             var result = MessageBox.Show(
                $"Вы уверены, что хотите удалить покупателя с ID {selectedRow["buyer_ID"]}?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes) return;

            MessageBox.Show($"Функция удаления покупателя для ID {selectedRow["buyer_ID"]} пока не реализована.");
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
} 