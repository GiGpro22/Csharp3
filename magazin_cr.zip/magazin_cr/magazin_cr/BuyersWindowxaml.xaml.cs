﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace magazin_cr
{
    /// <summary>
    /// Логика взаимодействия для BuyersWindowxaml.xaml
    /// </summary>
    public partial class BuyersWindow : Window
    {
        private magazinDataSet magazinDS;
        private magazinDataSetTableAdapters.BuyersTableAdapter buyersTA;

        public BuyersWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                magazinDS = new magazinDataSet();
                buyersTA = new magazinDataSetTableAdapters.BuyersTableAdapter();

                buyersTA.Fill(magazinDS.Buyers);
                BuyersGrid.ItemsSource = magazinDS.Buyers.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных покупателей: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BuyersGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView selectedRow = BuyersGrid.SelectedItem as DataRowView;
            bool hasSelection = selectedRow != null;
            EditBuyer.IsEnabled = hasSelection;
            DeleteBuyer.IsEnabled = hasSelection;
        }

        private void AddBuyer_Click(object sender, RoutedEventArgs e)
        {
            // Логика добавления покупателя
            MessageBox.Show("Функция добавления покупателя пока не реализована.");
        }

        private void EditBuyer_Click(object sender, RoutedEventArgs e)
        {
            // Логика редактирования покупателя
            if (BuyersGrid.SelectedItem == null) return;

            DataRowView selectedRow = (DataRowView)BuyersGrid.SelectedItem;
            MessageBox.Show($"Функция редактирования покупателя для ID {selectedRow["buyer_ID"]} пока не реализована.");
        }

        private void DeleteBuyer_Click(object sender, RoutedEventArgs e)
        {
            // Логика удаления покупателя
            if (BuyersGrid.SelectedItem == null) return;

            DataRowView selectedRow = (DataRowView)BuyersGrid.SelectedItem;

            var result = MessageBox.Show(
               $"Вы уверены, что хотите удалить покупателя с ID {selectedRow["buyer_ID"]}?",
               "Подтверждение удаления",
               MessageBoxButton.YesNo,
               MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes) return;

            MessageBox.Show($"Функция удаления покупателя для ID {selectedRow["buyer_ID"]} пока не реализована.");
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
