﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace magazin_cr
{
    /// <summary>
    /// Логика взаимодействия для EditSizeWindow.xaml
    /// </summary>
    public partial class EditSizeWindow : Window
    {
        public string Size
        {
            get { return SizeTextBox.Text; }
            set { SizeTextBox.Text = value; }
        }

        public string EuSize
        {
            get { return EuSizeTextBox.Text; }
            set { EuSizeTextBox.Text = value; }
        }

        public string UsSize
        {
            get { return UsSizeTextBox.Text; }
            set { UsSizeTextBox.Text = value; }
        }

        public string UkSize
        {
            get { return UkSizeTextBox.Text; }
            set { UkSizeTextBox.Text = value; }
        }

        public EditSizeWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Size))
            {
                MessageBox.Show("Пожалуйста, введите размер",
                    "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
