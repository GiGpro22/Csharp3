﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace magazin_cr
{
    /// <summary>
    /// Логика взаимодействия для EditBuyerWindow.xaml
    /// </summary>
    public partial class EditBuyerWindow : Window
    {
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string Email { get; private set; }
        public string Phone { get; private set; }

        private DataRowView _buyerRowView;

        // Конструктор для добавления покупателя
        public EditBuyerWindow()
        {
            InitializeComponent();
            Title = "Добавление покупателя";
        }

        // Конструктор для редактирования покупателя
        public EditBuyerWindow(DataRowView buyerRowView)
        {
            InitializeComponent();
            Title = "Редактирование покупателя";
            _buyerRowView = buyerRowView;

            // Заполнение полей данными из выбранной строки
            FirstNameTextBox.Text = buyerRowView["first_name"].ToString();
            LastNameTextBox.Text = buyerRowView["last_name"].ToString();
            EmailTextBox.Text = buyerRowView["email"].ToString();
            PhoneTextBox.Text = buyerRowView["phone"].ToString();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Базовая валидация (например, имя и фамилия не должны быть пустыми)
            if (string.IsNullOrWhiteSpace(FirstNameTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, введите имя покупателя.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(LastNameTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, введите фамилию покупателя.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Сохранение данных из полей
            FirstName = FirstNameTextBox.Text.Trim();
            LastName = LastNameTextBox.Text.Trim();
            Email = EmailTextBox.Text.Trim();
            Phone = PhoneTextBox.Text.Trim();

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
