﻿using System.Windows;

namespace magazin_cr
{
    public partial class EditBrandWindow : Window
    {
        public string BrandName { get; private set; }
        public string BrandDescription { get; private set; }

        public EditBrandWindow(string title = "Добавление бренда", string name = "", string description = "")
        {
            InitializeComponent();
            Title = title;
            txtName.Text = name;
            txtDescription.Text = description;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Пожалуйста, введите название бренда", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            BrandName = txtName.Text.Trim();
            BrandDescription = txtDescription.Text.Trim();
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
