﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin_cr
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Model_Click(object sender, RoutedEventArgs e)
        {
            Window1 modelWindow = new Window1();  
            modelWindow.Show();
            this.Close();
        }

        private void btn_Brand_Click(object sender, RoutedEventArgs e)
        {
            BrandsWindow brandsWindow = new BrandsWindow();
            brandsWindow.Show();
            this.Close();
            
        }

        private void btn_Kateg_Click(object sender, RoutedEventArgs e)
        {
            CategoriesWindow categoriesWindow = new CategoriesWindow();
            categoriesWindow.Show();
            this.Close();
        }

        private void btn_Razmer_Click(object sender, RoutedEventArgs e)
        {
            SizesWindow sizesWindow = new SizesWindow();
            sizesWindow.Show();
            this.Close();
        }

        private void btn_Product_Click(object sender, RoutedEventArgs e)
        {
            ProductsWindow productsWindow = new ProductsWindow();
            productsWindow.Show();
            this.Close();
        }

        private void btn_Pocup_Click(object sender, RoutedEventArgs e)
        {
            BuyersWindow buyersWindow = new BuyersWindow();
            buyersWindow.Show();
            this.Close();
        }

        private void btn_Prodaj_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
