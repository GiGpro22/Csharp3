﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Linq;
using System.Collections.Generic;

namespace magazin_cr
{
    public class ProductDisplayItem
    {
        public int product_ID { get; set; }
        public int model_ID { get; set; }
        public int size_ID { get; set; }   
        public string SKU { get; set; }
        public string Color { get; set; }
        public string ModelName { get; set; }
        public string SizeName { get; set; }
    }

    public partial class ProductsWindow : Window
    {
        private magazinDataSet magazinDS;
        private magazinDataSetTableAdapters.ProductsTableAdapter productsTA;
        private magazinDataSetTableAdapters.ModelsTableAdapter modelsTA;
        private magazinDataSetTableAdapters.SizesTableAdapter sizesTA;

        public ProductsWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                magazinDS = new magazinDataSet();
                productsTA = new magazinDataSetTableAdapters.ProductsTableAdapter();
                modelsTA = new magazinDataSetTableAdapters.ModelsTableAdapter();
                sizesTA = new magazinDataSetTableAdapters.SizesTableAdapter();

                productsTA.Fill(magazinDS.Products);
                modelsTA.Fill(magazinDS.Models);
                sizesTA.Fill(magazinDS.Sizes);

                var productView = from p in magazinDS.Products.AsEnumerable()
                                  join m in magazinDS.Models.AsEnumerable() on p.model_ID equals m.model_ID
                                  join s in magazinDS.Sizes.AsEnumerable() on p.size_ID equals s.size_ID
                                  select new ProductDisplayItem
                                  {
                                      product_ID = p.product_ID,
                                      model_ID = p.model_ID,
                                      size_ID = p.size_ID,
                                      SKU = p.sku,
                                      Color = p.color,
                                      ModelName = m.name,
                                      SizeName = s.size
                                  };

                ProductsGrid.ItemsSource = productView.ToList();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ProductsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool hasSelection = ProductsGrid.SelectedItem != null;
            EditProduct.IsEnabled = hasSelection;
            DeleteProduct.IsEnabled = hasSelection;
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new EditProductWindow();
            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    magazinDataSet.ProductsRow newProductRow = magazinDS.Products.NewProductsRow();
                    newProductRow.model_ID = editWindow.SelectedModelId;
                    newProductRow.size_ID = editWindow.SelectedSizeId;
                    newProductRow.sku = editWindow.Sku;
                    newProductRow.color = editWindow.Color;

                    magazinDS.Products.AddProductsRow(newProductRow);

                    productsTA.Update(magazinDS.Products);
                    LoadData();
                    MessageBox.Show("Продукт успешно добавлен!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении продукта: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsGrid.SelectedItem == null) return;


            var selectedItem = ProductsGrid.SelectedItem as ProductDisplayItem; 
            if (selectedItem == null) return; 

            var productRow = magazinDS.Products.FindByproduct_ID(selectedItem.product_ID); 

            if (productRow == null) return; 


            DataRowView productRowView = productRow.Table.DefaultView[productRow.Table.Rows.IndexOf(productRow)];

            var editWindow = new EditProductWindow(productRowView); 
            if (editWindow.ShowDialog() == true)
            {
                try
                {

                    productRow.model_ID = editWindow.SelectedModelId;
                    productRow.size_ID = editWindow.SelectedSizeId;
                    productRow.sku = editWindow.Sku;
                    productRow.color = editWindow.Color;


                    productsTA.Update(magazinDS.Products);
                    LoadData();
                    MessageBox.Show("Продукт успешно обновлён!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении продукта: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsGrid.SelectedItem == null) return;

            var result = MessageBox.Show(
                "Вы уверены, что хотите удалить этот продукт?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes) return;

            try
            {
                 var selectedItem = ProductsGrid.SelectedItem as ProductDisplayItem;
                 if (selectedItem == null) return; 


                 var productRow = magazinDS.Products.FindByproduct_ID(selectedItem.product_ID); 

                 if (productRow == null) return; 

                productRow.Delete();
                productsTA.Update(magazinDS.Products);
                LoadData();
                MessageBox.Show("Продукт успешно удалён!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                
                if (ex.Number == 547)
                {
                    MessageBox.Show("Невозможно удалить продукт, так как он используется в других записях (например, в продажах).",
                        "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    MessageBox.Show($"Ошибка базы данных при удалении продукта: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении продукта: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                LoadData(); 
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
