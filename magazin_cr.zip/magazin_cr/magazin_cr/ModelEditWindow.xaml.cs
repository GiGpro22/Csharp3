﻿using magazin_cr.magazinDataSetTableAdapters;
using System;
using System.Data;
using System.Windows;

namespace magazin_cr
{
    public partial class ModelEditWindow : Window
    {
        // Свойства для передачи данных модели
        public string ModelName { get; private set; }
        public string ModelDescription { get; private set; }
        public decimal Price { get; private set; }
        public DateTime ReleaseDate { get; private set; }
        public int BrandId { get; private set; }
        public int CategoryId { get; private set; }

        private ModelsTableAdapter modelsTA = new ModelsTableAdapter();
        private BrandsTableAdapter brandsTA = new BrandsTableAdapter();
        private CategoriesTableAdapter categoriesTA = new CategoriesTableAdapter();
        private magazinDataSet magazDS = new magazinDataSet();

        // Конструктор для добавления новой модели
        public ModelEditWindow()
        {
            InitializeComponent();
            Title = "Добавление модели";
            LoadComboBoxData();
        }

        // Конструктор для редактирования существующей модели
        public ModelEditWindow(string title, int modelId, int brandId, int categoryId, string name, string description, decimal price, DateTime releaseDate)
        {
            InitializeComponent();
            Title = title;

            // Загружаем существующие данные модели в поля
            txtName.Text = name;
            txtDescription.Text = description;
            txtPrice.Text = price.ToString();
            dpReleaseDate.SelectedDate = releaseDate;
            
            LoadComboBoxData();

            // Выбираем соответствующие значения в ComboBox'ах
            cmbBrand.SelectedValue = brandId;
            cmbCategory.SelectedValue = categoryId;
        }

        private void LoadComboBoxData()
        {
            try
            {
                // Загружаем данные для выпадающих списков брендов и категорий
                brandsTA.Fill(magazDS.Brands);
                cmbBrand.ItemsSource = magazDS.Brands.DefaultView;

                categoriesTA.Fill(magazDS.Categories);
                cmbCategory.ItemsSource = magazDS.Categories.DefaultView;
            }
            catch (Exception ex)
            {
                 MessageBox.Show($"Ошибка при загрузке данных для списков: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            // Валидация ввода
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Пожалуйста, введите название модели", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (cmbBrand.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите бренд", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (cmbCategory.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите категорию", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!decimal.TryParse(txtPrice.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Пожалуйста, введите корректную цену", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
             if (dpReleaseDate.SelectedDate == null)
            {
                MessageBox.Show("Пожалуйста, выберите дату выпуска", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Сохраняем данные из полей в свойства
            ModelName = txtName.Text.Trim();
            ModelDescription = txtDescription.Text.Trim();
            Price = price;
            ReleaseDate = dpReleaseDate.SelectedDate.Value;
            BrandId = (int)cmbBrand.SelectedValue;
            CategoryId = (int)cmbCategory.SelectedValue;

            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
