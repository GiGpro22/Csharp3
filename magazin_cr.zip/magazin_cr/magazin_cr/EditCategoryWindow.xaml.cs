using System.Windows;

namespace magazin_cr
{
    public partial class EditCategoryWindow : Window
    {
        public string CategoryName { get; private set; }
        public string CategoryDescription { get; private set; }

        public EditCategoryWindow(string title = "Добавление категории", string name = "", string description = "")
        {
            InitializeComponent();
            Title = title;
            txtName.Text = name;
            txtDescription.Text = description;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Пожалуйста, введите название категории", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            CategoryName = txtName.Text.Trim();
            CategoryDescription = txtDescription.Text.Trim();
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
} 