﻿namespace magazin_cr
{


    public partial class magazinDataSet
    {
    }
}
