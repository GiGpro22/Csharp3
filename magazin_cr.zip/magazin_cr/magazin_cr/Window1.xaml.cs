﻿using magazin_cr.magazinDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace magazin_cr
{

    public partial class Window1 : Window
    {
        private magazinDataSet magazDS;
        private ModelsTableAdapter modelsTA;

        public Window1()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                magazDS = new magazinDataSet();
                modelsTA = new ModelsTableAdapter();

                modelsTA.Fill(magazDS.Models);
                ModelsGrid.ItemsSource = magazDS.Models.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных моделей: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            // Предполагаем, что ModelEditWindow имеет конструктор по умолчанию и свойства для данных модели
            var editWindow = new ModelEditWindow(); // Возможно, потребуется передать данные для списков брендов и категорий
            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    // Создаем новую строку в таблице Models
                    magazinDataSet.ModelsRow newModelRow = magazDS.Models.NewModelsRow();

                    // Заполняем данные из окна редактирования
                    newModelRow.name = editWindow.ModelName; // Предполагаем свойство ModelName
                    newModelRow.description = editWindow.ModelDescription; // Предполагаем свойство ModelDescription
                    newModelRow.price = editWindow.Price; // Предполагаем свойство Price (decimal)
                    newModelRow.release_date = editWindow.ReleaseDate; // Предполагаем свойство ReleaseDate (DateTime)
                    newModelRow.brand_ID = editWindow.BrandId; // Предполагаем свойство BrandId (int)
                    newModelRow.category_ID = editWindow.CategoryId; // Предполагаем свойство CategoryId (int)

                    // Добавляем строку в коллекцию строк
                    magazDS.Models.AddModelsRow(newModelRow);

                    // Обновляем базу данных с помощью TableAdapter
                    modelsTA.Update(magazDS.Models);

                    LoadData(); // Перезагружаем данные для отображения изменений
                    MessageBox.Show("Модель успешно добавлена!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении модели: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    LoadData(); // Перезагружаем данные в случае ошибки
                }
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (ModelsGrid.SelectedItem == null) return;

            DataRowView row = (DataRowView)ModelsGrid.SelectedItem;
            
            // Предполагаем, что ModelEditWindow имеет конструктор для редактирования с параметрами
            var editWindow = new ModelEditWindow(
                "Редактирование модели",
                (int)row["model_ID"], // Передаем ID модели
                (int)row["brand_ID"], // Передаем Brand ID
                (int)row["category_ID"], // Передаем Category ID
                row["name"].ToString(),
                row["description"].ToString(),
                (decimal)row["price"],
                (DateTime)row["release_date"] // Предполагаем, что release_date не DBNull
            ); // Возможно, потребуется передать данные для списков брендов и категорий

            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    // Обновляем данные в строке DataRowView из окна редактирования
                    row["name"] = editWindow.ModelName;
                    row["description"] = editWindow.ModelDescription;
                    row["price"] = editWindow.Price;
                    row["release_date"] = editWindow.ReleaseDate;
                    row["brand_ID"] = editWindow.BrandId; // Обновляем Brand ID
                    row["category_ID"] = editWindow.CategoryId; // Обновляем Category ID

                    // Обновляем базу данных с помощью TableAdapter
                    modelsTA.Update(magazDS.Models);

                    LoadData(); // Перезагружаем данные для отображения изменений
                    MessageBox.Show("Модель успешно обновлена!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении модели: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    LoadData(); // Перезагружаем данные в случае ошибки
                }
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (ModelsGrid.SelectedItem == null) return;

            var result = MessageBox.Show(
                "Вы уверены, что хотите удалить эту модель?\n\n" +
                "Внимание: Если модель используется в продуктах, удаление будет невозможно.",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes) return;

            try
            {
                DataRowView row = (DataRowView)ModelsGrid.SelectedItem;
                row.Delete();
                modelsTA.Update(magazDS.Models);
                LoadData(); // Перезагружаем данные для отображения изменений
                MessageBox.Show("Модель успешно удалена!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Ошибка при удалении модели: {ex.Message}\n\n" +
                    "Возможно, эта модель используется в таблице продуктов.",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                LoadData(); // Перезагружаем данные в случае ошибки
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ModelsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool hasSelection = ModelsGrid.SelectedItem != null;
            btnEdit.IsEnabled = hasSelection;
            btnDelete.IsEnabled = hasSelection;
        }
    }
}
