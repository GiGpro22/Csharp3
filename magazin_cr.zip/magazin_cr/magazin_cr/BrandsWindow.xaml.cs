﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace magazin_cr
{
    public partial class BrandsWindow : Window
    {
        private magazinDataSet magazDS;
        private magazinDataSetTableAdapters.BrandsTableAdapter brandsTA;

        public BrandsWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                magazDS = new magazinDataSet();
                brandsTA = new magazinDataSetTableAdapters.BrandsTableAdapter();

                brandsTA.Fill(magazDS.Brands);
                BrandsGrid.ItemsSource = magazDS.Brands.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddBrand_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new EditBrandWindow();
            if (editWindow.ShowDialog() == true)
            {
                try
                {
 
                    magazinDataSet.BrandsRow newBrandRow = magazDS.Brands.NewBrandsRow();
                    newBrandRow.name = editWindow.BrandName;
                    newBrandRow.description = editWindow.BrandDescription;


                    magazDS.Brands.AddBrandsRow(newBrandRow);

                    brandsTA.Update(magazDS.Brands);

                    LoadData();
                    MessageBox.Show("Бренд успешно добавлен!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении бренда: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void EditBrand_Click(object sender, RoutedEventArgs e)
        {
            if (BrandsGrid.SelectedItem == null) return;

            DataRowView row = (DataRowView)BrandsGrid.SelectedItem;
            var editWindow = new EditBrandWindow(
                "Редактирование бренда",
                row["name"].ToString(),
                row["description"].ToString());

            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    row["name"] = editWindow.BrandName;
                    row["description"] = editWindow.BrandDescription;
                    brandsTA.Update(magazDS.Brands);
                    LoadData();
                    MessageBox.Show("Бренд успешно обновлён!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении бренда: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteBrand_Click(object sender, RoutedEventArgs e)
        {
            if (BrandsGrid.SelectedItem == null) return;

            var result = MessageBox.Show(
                "Вы уверены, что хотите удалить этот бренд?\n\n" +
                "Внимание: Если бренд используется в моделях, удаление будет невозможно.",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes) return;

            try
            {
                DataRowView row = (DataRowView)BrandsGrid.SelectedItem;
                row.Delete();
                brandsTA.Update(magazDS.Brands);
                LoadData();
                MessageBox.Show("Бренд успешно удалён!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                if (ex.Number == 547)
                {
                    MessageBox.Show("Невозможно удалить бренд, так как он используется в других записях (например, в моделях).",
                        "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    MessageBox.Show($"Ошибка базы данных при удалении бренда: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Ошибка при удалении бренда: {ex.Message}\n\n" +
                    "Возможно, этот бренд используется в таблице моделей.",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                LoadData();
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void BrandsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool hasSelection = BrandsGrid.SelectedItem != null;
            btnEdit.IsEnabled = hasSelection;
            btnDelete.IsEnabled = hasSelection;
        }
    }
}
